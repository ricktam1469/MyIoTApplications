package nagarro.iot.SmartSpeechBot.CanvasHandling;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.Log;
import android.widget.ImageView;

import nagarro.iot.SmartSpeechBot.Activity.MainActivity;
import nagarro.iot.SmartSpeechBot.R;

/**
 * Created by ricktamkundu on 26-10-2017.
 */

public class UpdateImageCanvas {

    private static Bitmap mutableBitmap;
    private static final String TAG = MainActivity.class.getSimpleName();

    public static void updateOnMap(Point point, ImageView mIimageView, Resources recourse) {
        try {
            BitmapFactory.Options myOptions = new BitmapFactory.Options();
            myOptions.inScaled = false;
            myOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;// important

            Bitmap bitmap = BitmapFactory.decodeResource(recourse, R.drawable.building371_gf, myOptions);
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setColor(Color.RED);

            Bitmap workingBitmap = Bitmap.createBitmap(bitmap);
            mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);

            Canvas canvas = new Canvas(mutableBitmap);
            canvas.drawCircle(point.x, point.y, 15, paint);
            Log.i(TAG, "update on map x-y=" + point.x + "-" + point.y);
            mIimageView.setAdjustViewBounds(true);
            mIimageView.setImageBitmap(mutableBitmap);
            mIimageView.invalidate();

        } catch (Exception e) {
            Log.d(TAG, e.getMessage());
        }
    }
}
