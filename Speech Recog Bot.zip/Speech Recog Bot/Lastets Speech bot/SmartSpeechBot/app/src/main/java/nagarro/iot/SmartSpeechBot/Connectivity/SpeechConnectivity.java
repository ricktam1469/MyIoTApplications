package nagarro.iot.SmartSpeechBot.Connectivity;

import android.content.Intent;
import android.speech.RecognizerIntent;

import java.util.Locale;

import nagarro.iot.SmartSpeechBot.Activity.MainActivity;

/**
 * Created by ricktamkundu on 26-10-2017.
 */

public class SpeechConnectivity {
    private static MainActivity activity;
    private static final int REQ_CODE_SPEECH_INPUT = 100;

    public SpeechConnectivity(MainActivity activity) {
        this.activity = activity;
    }

    public static Intent promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        return intent;
    }

}
