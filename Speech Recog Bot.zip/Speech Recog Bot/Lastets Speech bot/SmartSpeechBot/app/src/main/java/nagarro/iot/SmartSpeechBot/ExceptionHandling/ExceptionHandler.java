package nagarro.iot.SmartSpeechBot.ExceptionHandling;

import android.widget.Toast;

import nagarro.iot.SmartSpeechBot.Activity.MainActivity;

/**
 * Created by ricktamkundu on 26-10-2017.
 */

public class ExceptionHandler {

    private static MainActivity activity;

    public ExceptionHandler(MainActivity activity) {
        this.activity = activity;
    }

    public static void errorExit(String title, String message) {
        Toast.makeText(activity.getBaseContext(), title + " - " + message, Toast.LENGTH_LONG).show();
        activity.finish();
    }
}
