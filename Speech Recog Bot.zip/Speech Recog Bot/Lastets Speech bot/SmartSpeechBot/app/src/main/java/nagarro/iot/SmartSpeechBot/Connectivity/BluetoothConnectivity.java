package nagarro.iot.SmartSpeechBot.Connectivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.graphics.Point;
import android.os.Build;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.UUID;

import nagarro.iot.SmartSpeechBot.ExceptionHandling.ExceptionHandler;
import nagarro.iot.SmartSpeechBot.Activity.MainActivity;

import static nagarro.iot.SmartSpeechBot.ExceptionHandling.ExceptionHandler.errorExit;

/**
 * Created by ricktamkundu on 25-10-2017.
 */

public class BluetoothConnectivity {


    private static Point myPoints;
    private static BluetoothSocket btSocket = null;
    public static OutputStream outStream = null;
    private static final String TAG = MainActivity.class.getSimpleName();
    public static InputStream inStream = null;

    public static void init(Thread thread, String address, UUID MY_UUID, BluetoothAdapter btAdapter) {
        myPoints = new Point(0, 0);
        BluetoothDevice device = btAdapter.getRemoteDevice(address);
        try {
            btSocket = createBluetoothSocket(device, MY_UUID);
        } catch (IOException e1) {

            ExceptionHandler.errorExit("Fatal Error", "In onResume() and socket create failed: " + e1.getMessage() + ".");
        }
        try {
            btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            ExceptionHandler.errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
        }
        // Discovery is resource intensive.  Make sure it isn't going on
        // when you attempt to connect and pass your message.
        btAdapter.cancelDiscovery();
        // Establish the connection.  This will block until it connects.
        Log.d(TAG, "...Connecting...");
        try {
            btSocket.connect();
            Log.d(TAG, "...Connection ok...");
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {
                ExceptionHandler.errorExit("Fatal Error", "In onResume() and unable to close socket during connection failure" + e2.getMessage() + ".");
            }
        }
        // Create a data stream so we can talk to server.
        Log.d(TAG, "...Create Socket...");
        try {
            outStream = btSocket.getOutputStream();
            inStream = btSocket.getInputStream();
            if (thread.getState() == Thread.State.NEW) {
                thread.start();
            }
        } catch (IOException e) {
            ExceptionHandler.errorExit("Fatal Error", "In onResume() and output stream creation failed:" + e.getMessage() + ".");
        }
    }

    private static BluetoothSocket createBluetoothSocket(BluetoothDevice device, UUID MY_UUID) throws IOException {
        if (Build.VERSION.SDK_INT >= 10) {
            try {
                final Method m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", new Class[]{UUID.class});
                return (BluetoothSocket) m.invoke(device, MY_UUID);
            } catch (Exception e) {
                Log.e(TAG, "Could not create Insecure RFComm Connection", e);
            }
        }
        return device.createRfcommSocketToServiceRecord(MY_UUID);
    }

    public static void closeAllSocket() {
        if (outStream != null) {
            try {
                outStream.flush();
            } catch (IOException e) {
                errorExit("Fatal Error", "In onPause() and failed to flush output stream: " + e.getMessage() + ".");
            }
        }
        try {
            btSocket.close();
        } catch (IOException e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
        }

    }
}
