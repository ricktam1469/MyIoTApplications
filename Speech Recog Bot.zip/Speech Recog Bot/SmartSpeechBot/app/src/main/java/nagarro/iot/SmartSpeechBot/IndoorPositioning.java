package nagarro.iot.SmartSpeechBot;

import android.content.Context;
import android.graphics.Point;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by ricktamkundu on 10/20/2017.
 */

public class IndoorPositioning {

    void movementBot(char ch){

        if(ch=='F'){
            
        }
    }

}
