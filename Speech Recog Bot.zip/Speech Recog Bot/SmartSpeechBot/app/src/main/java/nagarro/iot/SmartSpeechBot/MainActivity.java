package nagarro.iot.SmartSpeechBot;


import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.messages.MessagesOptions;
import com.google.android.gms.nearby.messages.NearbyPermissions;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;


public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int PERMISSIONS_REQUEST_CODE = 1111;
    /*private static final String KEY_SUBSCRIBED = "subscribed";
    private boolean mSubscribed = false;*/
    private GoogleApiClient mGoogleApiClient;

    private IndoorPositioning mIndoorPositioning;
    private Point mTrilateratedPoint;

    private ImageView mIimageView;

    private Handler mHandler;
    private int delay = 2000; //milliseconds

    /////////////////////////////////////
    private TextView txtSpeechInput;
    private ImageButton btnSpeak;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private final int OK_JARVIS_SPEECH_INPUT = 200;
    //private Handler mHandler;
    private static final int MY_PERMISSIONS_REQUEST_BLUETOOTH = 1;
   // private static final String TAG = "bluetooth1";
    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private OutputStream outStream = null;
    private Button button;
    //private int delay = 2000; //milliseconds
    /* input stream used to read data from Bluetooth module */
    private InputStream inStream=null;

    // SPP UUID service
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // MAC-address of Bluetooth module (you must edit this line)
    private static String address = "00:21:13:01:D9:38";

    Thread thread;
    Point myPoints = new Point(1219, 391);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        mIimageView = (ImageView) findViewById(R.id.imageView);

       /* if (savedInstanceState != null) {
            mSubscribed = savedInstanceState.getBoolean(KEY_SUBSCRIBED, false);
        }*/

        if (!havePermissions()) {
            Log.i(TAG, "Requesting permissions needed for this app.");
            requestPermissions();
        }

       // txtSpeechInput = (TextView) findViewById(R.id.txtSpeechInput);
        btnSpeak = (ImageButton) findViewById(R.id.btnSpeak);
       // button=(Button) findViewById(R.id.button);
        askForBluettothPermission();

        btAdapter = BluetoothAdapter.getDefaultAdapter();
        checkBTState();
        //init();
        // hide the action bar
        //getActionBar().hide();

        btnSpeak.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                promptSpeechInput();
            }
        });

        ///Set marker at home////

        //mTrilateratedPoint = myPoints;
        updateOnMap(myPoints);
        /*button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("S");
            }
        });*/

        this.mHandler = new Handler();
        //MainActivity.this.mHandler.postDelayed(m_Runnable, delay);
        thread = new Thread(m_Runnable);


    }

    private final Runnable m_Runnable = new Runnable() {
        public void run()

        {
            listen();
            /*Point myPoints = new Point(1219, 391);
            //mTrilateratedPoint = mIndoorPositioning.getTrilateratedPoint();
            mTrilateratedPoint = myPoints;

            updateOnMap();*/
            //MainActivity.this.mHandler.postDelayed(m_Runnable, delay);
        }


    };

   /* @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (havePermissions()) {
            buildGoogleApiClient();
        }
    }*/

    @Override
    public void onStop() {
        //unsubscribe();
        super.onStop();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this, "Exception while connecting to google play services", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.w(TAG, "Connection suspended. Error code: " + i);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.i(TAG, "GoogleApiClient connected");
        // subscribe();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // outState.putBoolean(KEY_SUBSCRIBED, mSubscribed);
    }

    private boolean havePermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.BLUETOOTH}, PERMISSIONS_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode != PERMISSIONS_REQUEST_CODE) {
            return;
        }
        for (int i = 0; i < permissions.length; i++) {
            String permission = permissions[i];
            if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                if (shouldShowRequestPermissionRationale(permission)) {
                    Log.i(TAG, "Permission denied without 'NEVER ASK AGAIN': " + permission);
                } else {
                    Log.i(TAG, "Permission denied with 'NEVER ASK AGAIN': " + permission);
                }
            } else {
                Log.i(TAG, "Permission granted, building GoogleApiClient");
                buildGoogleApiClient();
            }
        }
    }

    private synchronized void buildGoogleApiClient() {
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(Nearby.MESSAGES_API, new MessagesOptions.Builder()
                            .setPermissions(NearbyPermissions.BLE)
                            .build())
                    .addConnectionCallbacks(this)
                    .enableAutoManage(this, this)
                    .build();
        }
    }

   /* private MessageListener mMessageListener = new MessageListener() {
        @Override
        public void onDistanceChanged(Message message, Distance distance) {
            String messageString = new String(message.getContent());
            if(mIndoorPositioning != null) {
                mIndoorPositioning.updatebeaconDistance(messageString, distance.getMeters());
            }
        }*/

        /*@Override
        public void onBleSignalChanged(Message message, BleSignal bleSignal) {
            String messageString = new String(message.getContent());
            Log.i(TAG, "message : " + messageString + "  RSSI : " + bleSignal.getRssi() + "  TX : " + bleSignal.getTxPower());
            super.onBleSignalChanged(message, bleSignal);
        }*/

        /*@Override
        public void onFound(Message message) {
            super.onFound(message);
        }
    };*/

    /*private void subscribe() {
        if (mSubscribed) {
            Log.i(TAG, "Already subscribed.");
            return;
        }

        SubscribeOptions options = new SubscribeOptions.Builder()
                .setStrategy(Strategy.BLE_ONLY)
                .build();

        Nearby.Messages.subscribe(mGoogleApiClient, mMessageListener, options)
                .setResultCallback(new ResultCallback<Status>() {
                    @Override
                    public void onResult(@NonNull Status status) {
                        if (status.isSuccess()) {
                            Log.i(TAG, "Subscribed successfully.");
                            mIndoorPositioning = new IndoorPositioning(MainActivity.this, "beacon.json");
                            MainActivity.this.mHandler.postDelayed(m_Runnable,delay);

                        } else {
                            Log.e(TAG, "Operation failed. Error: " +
                                    NearbyMessagesStatusCodes.getStatusCodeString(
                                            status.getStatusCode()));
                        }
                    }
                });
    }

    private void unsubscribe() {

        Log.i(TAG, "Unsubscribing.");
        Nearby.Messages.unsubscribe(mGoogleApiClient, mMessageListener);
    }
*/
    private void updateOnMap(Point point) {
        BitmapFactory.Options myOptions = new BitmapFactory.Options();
        myOptions.inScaled = false;
        myOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;// important

        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.building371_gf, myOptions);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.RED);


        Bitmap workingBitmap = Bitmap.createBitmap(bitmap);
        Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);


        Canvas canvas = new Canvas(mutableBitmap);

        canvas.drawCircle(point.x, point.y, 15, paint);
        Log.i(TAG, "update on map");
        mIimageView.setAdjustViewBounds(true);
        mIimageView.setImageBitmap(mutableBitmap);
    }


    public void listen() {
        // Keep listening to the InputStream until an exception occurs
        while (true) {
            try {
                // Read from the InputStream
                byte buffer[];
                buffer = new byte[1024];
                //Read is synchronous call which keeps on waiting until data is available
                int bytes = inStream.read(buffer);
                if(bytes > 0){
              /*If data is non zero which means a data has been sent from Arduino to
               Android */
                    //Do your stuff here
                    String strReceived = new String(buffer, 0, bytes);
                    final String msgReceived = String.valueOf(bytes) +
                            " bytes received:\n"
                            + strReceived;
                    if(strReceived.contains("Ricktam")){
                        //Point myPoints1 = new Point(1219, 1013);
                        //mTrilateratedPoint = myPoints1;
                        myPoints.x=1219;
                        myPoints.y=489;
                        updateOnMap(myPoints);
                    }
                }
            } catch (IOException e) {
                break;
            }
        }
    }
	/*final Runnable r = new Runnable() {
		public void run() {
			OkJarvisSpeechInput();
		}
	};*/
    /**
     * Showing google speech input dialog
     * */
    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));
        try {
            //onActivityResult(REQ_CODE_SPEECH_INPUT,REQ_CODE_SPEECH_INPUT,intent);
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }
    /**
     * Showing google speech input dialog
     * */
    private void OkJarvisSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));
        try {
            startActivityForResult(intent, OK_JARVIS_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }
    /**
     * Receiving speech input
     * */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        init();
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    int result_size=result.size();
                    int i=0;
                    while(result_size>i) {
                        if (result.get(i).contains("left")) {
                            sendData("L");
                            break;
                        }
                        if (result.get(i).contains("right")) {
                            sendData("R");
                            break;
                        }
                        if (result.get(i).contains("stop")) {
                            sendData("S");
                            break;
                        }
                        if (result.get(i).contains("forward")) {
                            sendData("F");
                            break;
                        }
                        if (result.get(i).contains("backward")) {
                            sendData("B");
                            break;
                        }
                        i++;
                    }
                }

                if (outStream != null) {
                    try {
                        outStream.flush();
                    } catch (IOException e) {
                        errorExit("Fatal Error", "In onPause() and failed to flush output stream: " + e.getMessage() + ".");
                    }
                }

                try     {
                    btSocket.close();
                } catch (IOException e2) {
                    errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
                }

                break;
            }

            case OK_JARVIS_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    if(result.get(0).equalsIgnoreCase("okay jarvis")){
                        promptSpeechInput();
                    }
                    if(result.get(0).equalsIgnoreCase("ok jarvis")){
                        promptSpeechInput();
                    }
                }
                break;
            }
        }
    }

    public void askForBluettothPermission() {
        //////////////Permission for Bluettoth/////////////////////////////////
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.BLUETOOTH)
                != PackageManager.PERMISSION_GRANTED) {
            //This method inside if returns true if the app has requested this permission
            // previously and the user denied the request.
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.BLUETOOTH)) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH},
                        MY_PERMISSIONS_REQUEST_BLUETOOTH);
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH},
                        MY_PERMISSIONS_REQUEST_BLUETOOTH);
            }
        }
        /////////////////////////////////////////////////////////////////////
    }

    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        if(Build.VERSION.SDK_INT >= 10){
            try {
                final Method m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", new Class[] { UUID.class });
                return (BluetoothSocket) m.invoke(device, MY_UUID);
            } catch (Exception e) {
                Log.e(TAG, "Could not create Insecure RFComm Connection",e);
            }
        }
        return  device.createRfcommSocketToServiceRecord(MY_UUID);
    }

    @Override
    public void onResume() {
        super.onResume();

        Log.d(TAG, "...onResume - try connect...");

        BluetoothDevice device=btAdapter.getRemoteDevice(address);
        // Set up a pointer to the remote node using it's address.
   /* Set<BluetoothDevice> devices = new ArraySet<BluetoothDevice>();
      devices.addAll(btAdapter.getBondedDevices());
   //BluetoothDevice device=
        Object[] o= devices.toArray();
      BluetoothDevice device=(BluetoothDevice)o[0];*/
        // Two things are needed to make a connection:
        //   A MAC address, which we got above.
        //   A Service ID or UUID.  In this case we are using the
        //     UUID for SPP.

        try {
            btSocket = createBluetoothSocket(device);
        } catch (IOException e1) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e1.getMessage() + ".");
        }

        try {
            btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
        }

        // Discovery is resource intensive.  Make sure it isn't going on
        // when you attempt to connect and pass your message.
        btAdapter.cancelDiscovery();

        // Establish the connection.  This will block until it connects.
        Log.d(TAG, "...Connecting...");
        try {
            btSocket.connect();
            Log.d(TAG, "...Connection ok...");
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {
                errorExit("Fatal Error", "In onResume() and unable to close socket during connection failure" + e2.getMessage() + ".");
            }
        }

        // Create a data stream so we can talk to server.
        Log.d(TAG, "...Create Socket...");

        try {
            outStream = btSocket.getOutputStream();
            inStream = btSocket.getInputStream();
            if (thread.getState() == Thread.State.NEW)
            {
                thread.start();
            }
            //if(!thread.isAlive()|| thread.isDaemon())
            //thread.start();
            //MainActivity.this.mHandler.postDelayed(m_Runnable, delay);

        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and output stream creation failed:" + e.getMessage() + ".");
        }
    }
    public void init(){

        BluetoothDevice device=btAdapter.getRemoteDevice(address);
        // Set up a pointer to the remote node using it's address.
   /* Set<BluetoothDevice> devices = new ArraySet<BluetoothDevice>();
      devices.addAll(btAdapter.getBondedDevices());
   //BluetoothDevice device=
        Object[] o= devices.toArray();
      BluetoothDevice device=(BluetoothDevice)o[0];*/
        // Two things are needed to make a connection:
        //   A MAC address, which we got above.
        //   A Service ID or UUID.  In this case we are using the
        //     UUID for SPP.

        try {
            btSocket = createBluetoothSocket(device);
        } catch (IOException e1) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e1.getMessage() + ".");
        }

        try {
            btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
        }

        // Discovery is resource intensive.  Make sure it isn't going on
        // when you attempt to connect and pass your message.
        btAdapter.cancelDiscovery();

        // Establish the connection.  This will block until it connects.
        Log.d(TAG, "...Connecting...");
        try {
            btSocket.connect();
            Log.d(TAG, "...Connection ok...");
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {
                errorExit("Fatal Error", "In onResume() and unable to close socket during connection failure" + e2.getMessage() + ".");
            }
        }

        // Create a data stream so we can talk to server.
        Log.d(TAG, "...Create Socket...");

        try {
            outStream = btSocket.getOutputStream();
            inStream = btSocket.getInputStream();
            if (thread.getState() == Thread.State.NEW)
            {
                thread.start();
            }
            //MainActivity.this.mHandler.postDelayed(m_Runnable, delay);

        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and output stream creation failed:" + e.getMessage() + ".");
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        Log.d(TAG, "...In onPause()...");

        if (outStream != null) {
            try {
                outStream.flush();
            } catch (IOException e) {
                errorExit("Fatal Error", "In onPause() and failed to flush output stream: " + e.getMessage() + ".");
            }
        }

        try     {
            btSocket.close();
        } catch (IOException e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
        }
    }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if(btAdapter==null) {
            errorExit("Fatal Error", "Bluetooth not support");
        } else {
            if (btAdapter.isEnabled()) {
                Log.d(TAG, "...Bluetooth ON...");
            } else {
                //Prompt user to turn on Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);
            }
        }
    }

    private void errorExit(String title, String message){
        Toast.makeText(getBaseContext(), title + " - " + message, Toast.LENGTH_LONG).show();
        finish();
    }

    private void sendData(String message) {
        byte[] msgBuffer = message.getBytes();

        Log.d(TAG, "...Send data: " + message + "...");

        try {
            outStream.write(msgBuffer);
        } catch (IOException e) {
            String msg = "In onResume() and an exception occurred during write: " + e.getMessage();
            if (address.equals("00:00:00:00:00:00"))
                msg = msg + ".\n\nUpdate your server address from 00:00:00:00:00:00 to the correct address on line 35 in the java code";
            msg = msg +  ".\n\nCheck that the SPP UUID: " + MY_UUID.toString() + " exists on server.\n\n";

            errorExit("Fatal Error", msg);
        }catch(Exception e){
            String msg = "exception " + e.getMessage();
        }



    }
}