package nagarro.iot.SmartSpeechBot.Activity;


import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import nagarro.iot.SmartSpeechBot.Connectivity.BluetoothConnectivity;
import nagarro.iot.SmartSpeechBot.Connectivity.SpeechConnectivity;
import nagarro.iot.SmartSpeechBot.R;

import static nagarro.iot.SmartSpeechBot.Connectivity.BluetoothConnectivity.closeAllSocket;
import static nagarro.iot.SmartSpeechBot.ExceptionHandling.ExceptionHandler.errorExit;
import static nagarro.iot.SmartSpeechBot.CanvasHandling.UpdateImageCanvas.updateOnMap;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private ImageView mIimageView;
    private ImageButton btnSpeak;
    private static final int REQ_CODE_SPEECH_INPUT = 100;
    private static final int MY_PERMISSIONS_REQUEST_BLUETOOTH = 1;
    private BluetoothAdapter btAdapter = null;
    // SPP UUID service
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    // MAC-address of Bluetooth module (you must edit this line)
    private static String address = "00:21:13:01:D9:38";

    Thread thread;
    Point myPoints = new Point(1219, 391);

    int flagR=0,flagU=0,flagM=0,flagP=0,home=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        mIimageView = (ImageView) findViewById(R.id.imageView);
        btnSpeak = (ImageButton) findViewById(R.id.btnSpeak);
        askForBluettothPermission();
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        checkBTState();
        btnSpeak.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = SpeechConnectivity.promptSpeechInput();
                try {
                    //onActivityResult(REQ_CODE_SPEECH_INPUT,REQ_CODE_SPEECH_INPUT,intent);
                    startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
                } catch (ActivityNotFoundException a) {
                    Toast.makeText(getApplicationContext(),
                            getString(R.string.speech_not_supported),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        ///Set marker at home////
        updateOnMap(myPoints, mIimageView, getResources());
        //sendData("P");
        thread = new Thread(m_Runnable);
    }

    private final Runnable m_Runnable = new Runnable() {
        public void run() {
            listen();
        }
    };

    public void askForBluettothPermission() {
        //////////////Permission for Bluettoth/////////////////////////////////
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.BLUETOOTH)
                != PackageManager.PERMISSION_GRANTED) {
            //This method inside if returns true if the app has requested this permission
            // previously and the user denied the request.
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.BLUETOOTH)) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH},
                        MY_PERMISSIONS_REQUEST_BLUETOOTH);
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH},
                        MY_PERMISSIONS_REQUEST_BLUETOOTH);
            }
        }
        /////////////////////////////////////////////////////////////////////
    }

    @Override
    public void onStop() {
        super.onStop();
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    public void listen() {
        // Keep listening to the InputStream until an exception occurs
        while (true) {

            try {
                thread.sleep(2000);
            } catch (InterruptedException e) {
                Log.e(TAG, "Interrupted listen wait", e);
            }
            try {
                // Read from the InputStream
                byte buffer[];
                buffer = new byte[1024];
                //Read is synchronous call which keeps on waiting until data is available
                int bytes = BluetoothConnectivity.inStream.read(buffer);
                if (bytes > 0) {
              /*If data is non zero which means a data has been sent from Arduino to
               Android */
                    String strReceived = new String(buffer, 0, bytes);
                    final String msgReceived = String.valueOf(bytes) +
                            " bytes received:\n"
                            + strReceived;
                    Log.d(TAG, "Data Received- " + strReceived);
                    if (strReceived.contains("Ricktam")) {
                        while (myPoints.y < 1013) {
                            myPoints.y = myPoints.y + 100;
                        }
                        flagR=1;
                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateOnMap(myPoints, mIimageView, getResources());
                            }
                        });
                    }
                    if (strReceived.contains("Ravi")) {
                        while (myPoints.y < 1013) {
                            myPoints.y = myPoints.y + 100;
                        }
                        while (myPoints.x > 400) {
                            myPoints.x = myPoints.x - 100;
                        }
                        flagR=1;
                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateOnMap(myPoints, mIimageView, getResources());
                            }
                        });
                    }
                    if (strReceived.contains("Manish")) {
                        while (myPoints.y < 1013) {
                            myPoints.y = myPoints.y + 1;
                        }
                        while (myPoints.x > 400) {
                            myPoints.x = myPoints.x - 1;
                        }
                        while (myPoints.y > 391) {
                            myPoints.y = myPoints.y - 1;
                        }
                        flagR=1;
                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateOnMap(myPoints, mIimageView, getResources());
                            }
                        });
                    }


                }
            } catch (IOException e) {
                Log.e(TAG, "Got an io exception while listen");
            }
        }
    }

    /**
     * Receiving speech input
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        BluetoothConnectivity.init(thread, address, MY_UUID, btAdapter);

        if(home==0){
            sendData("P");
            home++;
        }
        if(flagR==1){
            sendData("R");
            flagR=0;
        }
        if(flagU==1){
            sendData("U");
            flagU=0;
        }

        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    int result_size = result.size();
                    int i = 0;
                    while (result_size > i) {
                        if (result.get(i).contains("left")) {
                            sendData("L");
                            break;
                        }
                        if (result.get(i).contains("right")) {
                            sendData("R");
                            break;
                        }
                        if (result.get(i).contains("stop")) {
                            sendData("S");
                            break;
                        }
                        if (result.get(i).contains("forward")) {
                            sendData("F");
                            break;
                        }
                        if (result.get(i).contains("backward")) {
                            sendData("B");
                            break;
                        }
                        if (result.get(i).contains("ricktam")||result.get(i).contains("Ricktam")) {
                            sendData("R");
                            break;
                        }
                        if (result.get(i).contains("Ravi")|| result.get(i).contains("ravi")) {
                            sendData("U");
                            break;
                        }
                        if (result.get(i).contains("preet")||result.get(i).contains("Preet")) {
                            sendData("P");
                            break;
                        }
                        if (result.get(i).contains("manish")||result.get(i).contains("Manish")) {
                            sendData("M");
                            break;
                        }
                        i++;
                    }
                }
                closeAllSocket();
                break;
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        BluetoothConnectivity.init(thread, address, MY_UUID, btAdapter);

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "...In onPause()...");
        closeAllSocket();
    }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if (btAdapter == null) {
            errorExit("Fatal Error", "Bluetooth not support");
        } else {
            if (btAdapter.isEnabled()) {
                Log.d(TAG, "...Bluetooth ON...");
            } else {
                //Prompt user to turn on Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);
            }
        }
    }

    private void sendData(String message) {
        byte[] msgBuffer = message.getBytes();
        Log.d(TAG, "...Send data: " + message + "...");
        try {
            BluetoothConnectivity.outStream.write(msgBuffer);
        } catch (IOException e) {
            String msg = "In onResume() and an exception occurred during write: " + e.getMessage();
            if (address.equals("00:00:00:00:00:00"))
                msg = msg + ".\n\nUpdate your server address from 00:00:00:00:00:00 to the correct address on line 35 in the java code";
            msg = msg + ".\n\nCheck that the SPP UUID: " + MY_UUID.toString() + " exists on server.\n\n";

            errorExit("Fatal Error", msg);
        } catch (Exception e) {
            String msg = "exception " + e.getMessage();
        }
    }

}